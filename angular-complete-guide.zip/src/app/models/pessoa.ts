export interface IPessoa{
    codigo:number;
    nome:string;
}