import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ex-ngif-else',
  templateUrl: './ex-ngif-else.component.html',
  styleUrls: ['./ex-ngif-else.component.css']
})
export class ExNgifElseComponent implements OnInit {

  valor:boolean = false;

  constructor() { }

  ngOnInit() {
  }

}
